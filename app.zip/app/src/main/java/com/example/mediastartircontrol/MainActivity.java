package com.example.mediastartircontrol;

import android.app.Activity;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {

    private ConsumerIrManager irManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        irManager = (ConsumerIrManager) getSystemService(CONSUMER_IR_SERVICE);
        if (irManager == null || !irManager.hasIrEmitter()) {
            Toast.makeText(this, "IR Emitter not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        Button powerBtn = new Button(this);
        powerBtn.setText("Power");
        powerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendPowerCommand();
            }
        });

        layout.addView(powerBtn);

        setContentView(layout);
    }

    private void sendPowerCommand() {
        int frequency = 38000; // فرکانس 38 کیلوهرتز
        int[] pattern = {9000,4500,560,560,560,560,560,1690,560,1690}; // الگوی ارسال IR
        irManager.transmit(frequency, pattern);
        Toast.makeText(this, "Power command sent", Toast.LENGTH_SHORT).show();
    }
}